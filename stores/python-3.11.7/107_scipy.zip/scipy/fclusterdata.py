"""
fclusterdata from scipy
Route: POST /api/scipy/fclusterdata
"""

import inspect
import scipy

def help():
    try:
        func = getattr(scipy, "fclusterdata")
        sig = inspect.signature(func)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/scipy/fclusterdata",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "fclusterdata from scipy"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        func = getattr(scipy, "fclusterdata")
        
        if params:
            result = func(**params)
        else:
            result = func()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "scipy"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
