"""
all_estimators from sklearn
Route: POST /api/sklearn/all_estimators
"""

import inspect
from sklearn.discovery import all_estimators

def help():
    try:
        sig = inspect.signature(all_estimators)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/all_estimators",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "all_estimators from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = all_estimators(**params)
        else:
            result = all_estimators()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
