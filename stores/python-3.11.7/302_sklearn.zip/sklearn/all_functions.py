"""
all_functions from sklearn
Route: POST /api/sklearn/all_functions
"""

import inspect
from sklearn.discovery import all_functions

def help():
    try:
        sig = inspect.signature(all_functions)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/all_functions",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "all_functions from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = all_functions(**params)
        else:
            result = all_functions()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
