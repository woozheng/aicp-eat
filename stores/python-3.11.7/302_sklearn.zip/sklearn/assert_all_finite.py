"""
assert_all_finite from sklearn
Route: POST /api/sklearn/assert_all_finite
"""

import inspect
from sklearn.validation import assert_all_finite

def help():
    try:
        sig = inspect.signature(assert_all_finite)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/assert_all_finite",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "assert_all_finite from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = assert_all_finite(**params)
        else:
            result = assert_all_finite()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
