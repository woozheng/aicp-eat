"""
assert_request_equal from sklearn
Route: POST /api/sklearn/assert_request_equal
"""

import inspect
from sklearn.metadata_routing_common import assert_request_equal

def help():
    try:
        sig = inspect.signature(assert_request_equal)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/assert_request_equal",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "assert_request_equal from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = assert_request_equal(**params)
        else:
            result = assert_request_equal()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
