"""
build_preprocessor from sklearn
Route: POST /api/sklearn/build_preprocessor
"""

import inspect
from sklearn.text import build_preprocessor

def help():
    try:
        sig = inspect.signature(build_preprocessor)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/build_preprocessor",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "build_preprocessor from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = build_preprocessor(**params)
        else:
            result = build_preprocessor()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
