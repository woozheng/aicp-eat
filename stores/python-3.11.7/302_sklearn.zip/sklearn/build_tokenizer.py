"""
build_tokenizer from sklearn
Route: POST /api/sklearn/build_tokenizer
"""

import inspect
from sklearn.text import build_tokenizer

def help():
    try:
        sig = inspect.signature(build_tokenizer)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/build_tokenizer",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "build_tokenizer from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = build_tokenizer(**params)
        else:
            result = build_tokenizer()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
