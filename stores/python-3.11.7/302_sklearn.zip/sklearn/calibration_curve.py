"""
calibration_curve from sklearn
Route: POST /api/sklearn/calibration_curve
"""

import inspect
from sklearn.calibration import calibration_curve

def help():
    try:
        sig = inspect.signature(calibration_curve)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/calibration_curve",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "calibration_curve from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = calibration_curve(**params)
        else:
            result = calibration_curve()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
