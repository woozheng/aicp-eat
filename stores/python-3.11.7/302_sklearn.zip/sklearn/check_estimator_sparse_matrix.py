"""
check_estimator_sparse_matrix from sklearn
Route: POST /api/sklearn/check_estimator_sparse_matrix
"""

import inspect
from sklearn.estimator_checks import check_estimator_sparse_matrix

def help():
    try:
        sig = inspect.signature(check_estimator_sparse_matrix)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/check_estimator_sparse_matrix",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "check_estimator_sparse_matrix from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = check_estimator_sparse_matrix(**params)
        else:
            result = check_estimator_sparse_matrix()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
