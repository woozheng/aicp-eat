"""
check_fit_check_is_fitted from sklearn
Route: POST /api/sklearn/check_fit_check_is_fitted
"""

import inspect
from sklearn.estimator_checks import check_fit_check_is_fitted

def help():
    try:
        sig = inspect.signature(check_fit_check_is_fitted)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/check_fit_check_is_fitted",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "check_fit_check_is_fitted from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = check_fit_check_is_fitted(**params)
        else:
            result = check_fit_check_is_fitted()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
