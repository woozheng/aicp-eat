"""
check_recorded_metadata from sklearn
Route: POST /api/sklearn/check_recorded_metadata
"""

import inspect
from sklearn.metadata_routing_common import check_recorded_metadata

def help():
    try:
        sig = inspect.signature(check_recorded_metadata)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/check_recorded_metadata",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "check_recorded_metadata from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = check_recorded_metadata(**params)
        else:
            result = check_recorded_metadata()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
