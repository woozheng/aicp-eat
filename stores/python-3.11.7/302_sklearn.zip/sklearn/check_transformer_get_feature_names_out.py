"""
check_transformer_get_feature_names_out from sklearn
Route: POST /api/sklearn/check_transformer_get_feature_names_out
"""

import inspect
from sklearn.estimator_checks import check_transformer_get_feature_names_out

def help():
    try:
        sig = inspect.signature(check_transformer_get_feature_names_out)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/check_transformer_get_feature_names_out",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "check_transformer_get_feature_names_out from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = check_transformer_get_feature_names_out(**params)
        else:
            result = check_transformer_get_feature_names_out()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
