"""
check_transformer_preserve_dtypes from sklearn
Route: POST /api/sklearn/check_transformer_preserve_dtypes
"""

import inspect
from sklearn.estimator_checks import check_transformer_preserve_dtypes

def help():
    try:
        sig = inspect.signature(check_transformer_preserve_dtypes)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/check_transformer_preserve_dtypes",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "check_transformer_preserve_dtypes from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = check_transformer_preserve_dtypes(**params)
        else:
            result = check_transformer_preserve_dtypes()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
