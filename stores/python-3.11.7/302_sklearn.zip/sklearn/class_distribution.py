"""
class_distribution from sklearn
Route: POST /api/sklearn/class_distribution
"""

import inspect
from sklearn.multiclass import class_distribution

def help():
    try:
        sig = inspect.signature(class_distribution)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/class_distribution",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "class_distribution from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = class_distribution(**params)
        else:
            result = class_distribution()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
