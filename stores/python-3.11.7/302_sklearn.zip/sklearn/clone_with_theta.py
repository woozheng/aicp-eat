"""
clone_with_theta from sklearn
Route: POST /api/sklearn/clone_with_theta
"""

import inspect
from sklearn.kernels import clone_with_theta

def help():
    try:
        sig = inspect.signature(clone_with_theta)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/clone_with_theta",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "clone_with_theta from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = clone_with_theta(**params)
        else:
            result = clone_with_theta()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
