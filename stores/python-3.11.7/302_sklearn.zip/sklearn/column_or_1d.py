"""
column_or_1d from sklearn
Route: POST /api/sklearn/column_or_1d
"""

import inspect
from sklearn.validation import column_or_1d

def help():
    try:
        sig = inspect.signature(column_or_1d)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/column_or_1d",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "column_or_1d from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = column_or_1d(**params)
        else:
            result = column_or_1d()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
