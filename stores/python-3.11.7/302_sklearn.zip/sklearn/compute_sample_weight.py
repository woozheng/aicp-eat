"""
compute_sample_weight from sklearn
Route: POST /api/sklearn/compute_sample_weight
"""

import inspect
from sklearn.class_weight import compute_sample_weight

def help():
    try:
        sig = inspect.signature(compute_sample_weight)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/compute_sample_weight",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "compute_sample_weight from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = compute_sample_weight(**params)
        else:
            result = compute_sample_weight()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
