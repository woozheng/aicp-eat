"""
convert_dtype from sklearn
Route: POST /api/sklearn/convert_dtype
"""

import inspect
from sklearn.extmath import convert_dtype

def help():
    try:
        sig = inspect.signature(convert_dtype)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/convert_dtype",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "convert_dtype from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = convert_dtype(**params)
        else:
            result = convert_dtype()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
