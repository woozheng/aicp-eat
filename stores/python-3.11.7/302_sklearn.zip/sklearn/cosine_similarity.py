"""
cosine_similarity from sklearn
Route: POST /api/sklearn/cosine_similarity
"""

import inspect
from sklearn.pairwise import cosine_similarity

def help():
    try:
        sig = inspect.signature(cosine_similarity)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/cosine_similarity",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "cosine_similarity from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = cosine_similarity(**params)
        else:
            result = cosine_similarity()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
