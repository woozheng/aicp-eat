"""
create_dataframe from sklearn
Route: POST /api/sklearn/create_dataframe
"""

import inspect
from sklearn.estimator_checks import create_dataframe

def help():
    try:
        sig = inspect.signature(create_dataframe)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/create_dataframe",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "create_dataframe from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = create_dataframe(**params)
        else:
            result = create_dataframe()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
