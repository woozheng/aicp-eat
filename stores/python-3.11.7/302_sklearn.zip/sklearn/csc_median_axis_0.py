"""
csc_median_axis_0 from sklearn
Route: POST /api/sklearn/csc_median_axis_0
"""

import inspect
from sklearn.sparsefuncs import csc_median_axis_0

def help():
    try:
        sig = inspect.signature(csc_median_axis_0)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/csc_median_axis_0",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "csc_median_axis_0 from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = csc_median_axis_0(**params)
        else:
            result = csc_median_axis_0()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
