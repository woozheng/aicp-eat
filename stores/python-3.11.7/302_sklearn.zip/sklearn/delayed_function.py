"""
delayed_function from sklearn
Route: POST /api/sklearn/delayed_function
"""

import inspect
from sklearn.parallel import delayed_function

def help():
    try:
        sig = inspect.signature(delayed_function)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/delayed_function",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "delayed_function from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = delayed_function(**params)
        else:
            result = delayed_function()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
