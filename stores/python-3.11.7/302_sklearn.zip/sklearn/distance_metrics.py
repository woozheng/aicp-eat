"""
distance_metrics from sklearn
Route: POST /api/sklearn/distance_metrics
"""

import inspect
from sklearn.pairwise import distance_metrics

def help():
    try:
        sig = inspect.signature(distance_metrics)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/distance_metrics",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "distance_metrics from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = distance_metrics(**params)
        else:
            result = distance_metrics()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
