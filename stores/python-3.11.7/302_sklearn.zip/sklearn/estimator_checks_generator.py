"""
estimator_checks_generator from sklearn
Route: POST /api/sklearn/estimator_checks_generator
"""

import inspect
from sklearn.estimator_checks import estimator_checks_generator

def help():
    try:
        sig = inspect.signature(estimator_checks_generator)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/estimator_checks_generator",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "estimator_checks_generator from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = estimator_checks_generator(**params)
        else:
            result = estimator_checks_generator()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
