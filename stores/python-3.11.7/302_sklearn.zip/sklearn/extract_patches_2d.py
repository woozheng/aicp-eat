"""
extract_patches_2d from sklearn
Route: POST /api/sklearn/extract_patches_2d
"""

import inspect
from sklearn.image import extract_patches_2d

def help():
    try:
        sig = inspect.signature(extract_patches_2d)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/extract_patches_2d",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "extract_patches_2d from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = extract_patches_2d(**params)
        else:
            result = extract_patches_2d()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
