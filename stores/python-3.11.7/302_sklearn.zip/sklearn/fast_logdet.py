"""
fast_logdet from sklearn
Route: POST /api/sklearn/fast_logdet
"""

import inspect
from sklearn.extmath import fast_logdet

def help():
    try:
        sig = inspect.signature(fast_logdet)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/fast_logdet",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "fast_logdet from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = fast_logdet(**params)
        else:
            result = fast_logdet()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
