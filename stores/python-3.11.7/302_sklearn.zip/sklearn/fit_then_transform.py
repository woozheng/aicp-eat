"""
fit_then_transform from sklearn
Route: POST /api/sklearn/fit_then_transform
"""

import inspect
from sklearn.estimator_checks import fit_then_transform

def help():
    try:
        sig = inspect.signature(fit_then_transform)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/fit_then_transform",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "fit_then_transform from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = fit_then_transform(**params)
        else:
            result = fit_then_transform()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
