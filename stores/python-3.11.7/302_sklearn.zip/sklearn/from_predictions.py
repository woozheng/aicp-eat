"""
from_predictions from sklearn
Route: POST /api/sklearn/from_predictions
"""

import inspect
from sklearn.calibration import from_predictions

def help():
    try:
        sig = inspect.signature(from_predictions)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/from_predictions",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "from_predictions from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = from_predictions(**params)
        else:
            result = from_predictions()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
