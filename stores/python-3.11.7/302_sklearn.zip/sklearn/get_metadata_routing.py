"""
get_metadata_routing from sklearn
Route: POST /api/sklearn/get_metadata_routing
"""

import inspect
from sklearn.calibration import get_metadata_routing

def help():
    try:
        sig = inspect.signature(get_metadata_routing)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/get_metadata_routing",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "get_metadata_routing from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = get_metadata_routing(**params)
        else:
            result = get_metadata_routing()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
