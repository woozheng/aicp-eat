"""
get_n_splits from sklearn
Route: POST /api/sklearn/get_n_splits
"""

import inspect
from sklearn.common import get_n_splits

def help():
    try:
        sig = inspect.signature(get_n_splits)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/get_n_splits",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "get_n_splits from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = get_n_splits(**params)
        else:
            result = get_n_splits()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
