"""
get_shape from sklearn
Route: POST /api/sklearn/get_shape
"""

import inspect
from sklearn.base import get_shape

def help():
    try:
        sig = inspect.signature(get_shape)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/get_shape",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "get_shape from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = get_shape(**params)
        else:
            result = get_shape()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
