"""
has_fit_parameter from sklearn
Route: POST /api/sklearn/has_fit_parameter
"""

import inspect
from sklearn.validation import has_fit_parameter

def help():
    try:
        sig = inspect.signature(has_fit_parameter)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/has_fit_parameter",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "has_fit_parameter from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = has_fit_parameter(**params)
        else:
            result = has_fit_parameter()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
