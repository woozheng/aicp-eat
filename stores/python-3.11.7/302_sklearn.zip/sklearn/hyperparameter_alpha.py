"""
hyperparameter_alpha from sklearn
Route: POST /api/sklearn/hyperparameter_alpha
"""

import inspect
from sklearn.kernels import hyperparameter_alpha

def help():
    try:
        sig = inspect.signature(hyperparameter_alpha)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/hyperparameter_alpha",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "hyperparameter_alpha from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = hyperparameter_alpha(**params)
        else:
            result = hyperparameter_alpha()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
