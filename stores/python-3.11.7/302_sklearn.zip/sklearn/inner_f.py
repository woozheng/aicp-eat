"""
inner_f from sklearn
Route: POST /api/sklearn/inner_f
"""

import inspect
from sklearn.validation import inner_f

def help():
    try:
        sig = inspect.signature(inner_f)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/inner_f",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "inner_f from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = inner_f(**params)
        else:
            result = inner_f()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
