"""
inplace_swap_column from sklearn
Route: POST /api/sklearn/inplace_swap_column
"""

import inspect
from sklearn.sparsefuncs import inplace_swap_column

def help():
    try:
        sig = inspect.signature(inplace_swap_column)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/inplace_swap_column",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "inplace_swap_column from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = inplace_swap_column(**params)
        else:
            result = inplace_swap_column()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
