"""
is_abstract from sklearn
Route: POST /api/sklearn/is_abstract
"""

import inspect
from sklearn.discovery import is_abstract

def help():
    try:
        sig = inspect.signature(is_abstract)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/is_abstract",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "is_abstract from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = is_abstract(**params)
        else:
            result = is_abstract()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
