"""
is_clusterer from sklearn
Route: POST /api/sklearn/is_clusterer
"""

import inspect
from sklearn.base import is_clusterer

def help():
    try:
        sig = inspect.signature(is_clusterer)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/is_clusterer",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "is_clusterer from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = is_clusterer(**params)
        else:
            result = is_clusterer()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
