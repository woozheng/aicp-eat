"""
is_non_default from sklearn
Route: POST /api/sklearn/is_non_default
"""

import inspect
from sklearn.base import is_non_default

def help():
    try:
        sig = inspect.signature(is_non_default)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/is_non_default",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "is_non_default from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = is_non_default(**params)
        else:
            result = is_non_default()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
