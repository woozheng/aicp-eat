"""
johnson_lindenstrauss_min_dim from sklearn
Route: POST /api/sklearn/johnson_lindenstrauss_min_dim
"""

import inspect
from sklearn.random_projection import johnson_lindenstrauss_min_dim

def help():
    try:
        sig = inspect.signature(johnson_lindenstrauss_min_dim)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/johnson_lindenstrauss_min_dim",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "johnson_lindenstrauss_min_dim from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = johnson_lindenstrauss_min_dim(**params)
        else:
            result = johnson_lindenstrauss_min_dim()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
