"""
laplacian_kernel from sklearn
Route: POST /api/sklearn/laplacian_kernel
"""

import inspect
from sklearn.pairwise import laplacian_kernel

def help():
    try:
        sig = inspect.signature(laplacian_kernel)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/laplacian_kernel",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "laplacian_kernel from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = laplacian_kernel(**params)
        else:
            result = laplacian_kernel()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
