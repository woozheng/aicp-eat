"""
log_loss from sklearn
Route: POST /api/sklearn/log_loss
"""

import inspect
from sklearn.calibration import log_loss

def help():
    try:
        sig = inspect.signature(log_loss)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/log_loss",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "log_loss from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = log_loss(**params)
        else:
            result = log_loss()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
