"""
loss_grad from sklearn
Route: POST /api/sklearn/loss_grad
"""

import inspect
from sklearn.calibration import loss_grad

def help():
    try:
        sig = inspect.signature(loss_grad)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/loss_grad",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "loss_grad from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = loss_grad(**params)
        else:
            result = loss_grad()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
