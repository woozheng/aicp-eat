"""
make_nonnegative from sklearn
Route: POST /api/sklearn/make_nonnegative
"""

import inspect
from sklearn.extmath import make_nonnegative

def help():
    try:
        sig = inspect.signature(make_nonnegative)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/make_nonnegative",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "make_nonnegative from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = make_nonnegative(**params)
        else:
            result = make_nonnegative()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
