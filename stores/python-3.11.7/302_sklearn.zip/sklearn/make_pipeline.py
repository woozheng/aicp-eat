"""
make_pipeline from sklearn
Route: POST /api/sklearn/make_pipeline
"""

import inspect
from sklearn.pipeline import make_pipeline

def help():
    try:
        sig = inspect.signature(make_pipeline)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/make_pipeline",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "make_pipeline from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = make_pipeline(**params)
        else:
            result = make_pipeline()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
