"""
mean_variance_axis from sklearn
Route: POST /api/sklearn/mean_variance_axis
"""

import inspect
from sklearn.sparsefuncs import mean_variance_axis

def help():
    try:
        sig = inspect.signature(mean_variance_axis)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/mean_variance_axis",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "mean_variance_axis from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = mean_variance_axis(**params)
        else:
            result = mean_variance_axis()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
