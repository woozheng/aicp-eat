"""
min_max_axis from sklearn
Route: POST /api/sklearn/min_max_axis
"""

import inspect
from sklearn.sparsefuncs import min_max_axis

def help():
    try:
        sig = inspect.signature(min_max_axis)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/min_max_axis",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "min_max_axis from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = min_max_axis(**params)
        else:
            result = min_max_axis()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
