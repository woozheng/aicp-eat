"""
n_features_in_ from sklearn
Route: POST /api/sklearn/n_features_in_
"""

import inspect
from sklearn.pipeline import n_features_in_

def help():
    try:
        sig = inspect.signature(n_features_in_)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/n_features_in_",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "n_features_in_ from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = n_features_in_(**params)
        else:
            result = n_features_in_()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
