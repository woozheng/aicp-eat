"""
named_steps from sklearn
Route: POST /api/sklearn/named_steps
"""

import inspect
from sklearn.pipeline import named_steps

def help():
    try:
        sig = inspect.signature(named_steps)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/named_steps",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "named_steps from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = named_steps(**params)
        else:
            result = named_steps()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
