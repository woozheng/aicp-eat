"""
pairwise_distances from sklearn
Route: POST /api/sklearn/pairwise_distances
"""

import inspect
from sklearn.pairwise import pairwise_distances

def help():
    try:
        sig = inspect.signature(pairwise_distances)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/pairwise_distances",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "pairwise_distances from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = pairwise_distances(**params)
        else:
            result = pairwise_distances()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
