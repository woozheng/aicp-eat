"""
pairwise_distances_chunked from sklearn
Route: POST /api/sklearn/pairwise_distances_chunked
"""

import inspect
from sklearn.pairwise import pairwise_distances_chunked

def help():
    try:
        sig = inspect.signature(pairwise_distances_chunked)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/pairwise_distances_chunked",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "pairwise_distances_chunked from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = pairwise_distances_chunked(**params)
        else:
            result = pairwise_distances_chunked()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
