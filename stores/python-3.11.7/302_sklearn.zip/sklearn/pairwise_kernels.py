"""
pairwise_kernels from sklearn
Route: POST /api/sklearn/pairwise_kernels
"""

import inspect
from sklearn.pairwise import pairwise_kernels

def help():
    try:
        sig = inspect.signature(pairwise_kernels)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/pairwise_kernels",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "pairwise_kernels from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = pairwise_kernels(**params)
        else:
            result = pairwise_kernels()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
