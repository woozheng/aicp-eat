"""
parametrize_with_checks from sklearn
Route: POST /api/sklearn/parametrize_with_checks
"""

import inspect
from sklearn.estimator_checks import parametrize_with_checks

def help():
    try:
        sig = inspect.signature(parametrize_with_checks)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/parametrize_with_checks",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "parametrize_with_checks from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = parametrize_with_checks(**params)
        else:
            result = parametrize_with_checks()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
