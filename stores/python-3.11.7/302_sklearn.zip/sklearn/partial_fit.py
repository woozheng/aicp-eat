"""
partial_fit from sklearn
Route: POST /api/sklearn/partial_fit
"""

import inspect
from sklearn.multiclass import partial_fit

def help():
    try:
        sig = inspect.signature(partial_fit)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/partial_fit",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "partial_fit from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = partial_fit(**params)
        else:
            result = partial_fit()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
