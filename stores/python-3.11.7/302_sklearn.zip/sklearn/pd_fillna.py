"""
pd_fillna from sklearn
Route: POST /api/sklearn/pd_fillna
"""

import inspect
from sklearn.fixes import pd_fillna

def help():
    try:
        sig = inspect.signature(pd_fillna)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/pd_fillna",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "pd_fillna from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = pd_fillna(**params)
        else:
            result = pd_fillna()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
