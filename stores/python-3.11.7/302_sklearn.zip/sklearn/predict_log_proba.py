"""
predict_log_proba from sklearn
Route: POST /api/sklearn/predict_log_proba
"""

import inspect
from sklearn.discriminant_analysis import predict_log_proba

def help():
    try:
        sig = inspect.signature(predict_log_proba)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/predict_log_proba",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "predict_log_proba from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = predict_log_proba(**params)
        else:
            result = predict_log_proba()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
