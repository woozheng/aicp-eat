"""
randomized_range_finder from sklearn
Route: POST /api/sklearn/randomized_range_finder
"""

import inspect
from sklearn.extmath import randomized_range_finder

def help():
    try:
        sig = inspect.signature(randomized_range_finder)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/randomized_range_finder",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "randomized_range_finder from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = randomized_range_finder(**params)
        else:
            result = randomized_range_finder()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
