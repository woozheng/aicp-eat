"""
reconstruct_from_patches_2d from sklearn
Route: POST /api/sklearn/reconstruct_from_patches_2d
"""

import inspect
from sklearn.image import reconstruct_from_patches_2d

def help():
    try:
        sig = inspect.signature(reconstruct_from_patches_2d)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/reconstruct_from_patches_2d",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "reconstruct_from_patches_2d from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = reconstruct_from_patches_2d(**params)
        else:
            result = reconstruct_from_patches_2d()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
