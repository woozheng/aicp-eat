"""
safe_sqr from sklearn
Route: POST /api/sklearn/safe_sqr
"""

import inspect
from sklearn.extmath import safe_sqr

def help():
    try:
        sig = inspect.signature(safe_sqr)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/safe_sqr",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "safe_sqr from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = safe_sqr(**params)
        else:
            result = safe_sqr()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
