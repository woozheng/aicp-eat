"""
sparse_matmul_to_dense from sklearn
Route: POST /api/sklearn/sparse_matmul_to_dense
"""

import inspect
from sklearn.sparsefuncs import sparse_matmul_to_dense

def help():
    try:
        sig = inspect.signature(sparse_matmul_to_dense)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/sparse_matmul_to_dense",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "sparse_matmul_to_dense from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = sparse_matmul_to_dense(**params)
        else:
            result = sparse_matmul_to_dense()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
