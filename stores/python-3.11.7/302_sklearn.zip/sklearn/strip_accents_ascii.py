"""
strip_accents_ascii from sklearn
Route: POST /api/sklearn/strip_accents_ascii
"""

import inspect
from sklearn.text import strip_accents_ascii

def help():
    try:
        sig = inspect.signature(strip_accents_ascii)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/strip_accents_ascii",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "strip_accents_ascii from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = strip_accents_ascii(**params)
        else:
            result = strip_accents_ascii()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
