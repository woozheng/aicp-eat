"""
strip_accents_unicode from sklearn
Route: POST /api/sklearn/strip_accents_unicode
"""

import inspect
from sklearn.text import strip_accents_unicode

def help():
    try:
        sig = inspect.signature(strip_accents_unicode)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/strip_accents_unicode",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "strip_accents_unicode from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = strip_accents_unicode(**params)
        else:
            result = strip_accents_unicode()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
