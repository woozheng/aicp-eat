"""
strip_tags from sklearn
Route: POST /api/sklearn/strip_tags
"""

import inspect
from sklearn.text import strip_tags

def help():
    try:
        sig = inspect.signature(strip_tags)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/strip_tags",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "strip_tags from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = strip_tags(**params)
        else:
            result = strip_tags()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
