"""
svd_flip from sklearn
Route: POST /api/sklearn/svd_flip
"""

import inspect
from sklearn.extmath import svd_flip

def help():
    try:
        sig = inspect.signature(svd_flip)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/svd_flip",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "svd_flip from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = svd_flip(**params)
        else:
            result = svd_flip()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
