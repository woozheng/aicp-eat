"""
svdvals from sklearn
Route: POST /api/sklearn/svdvals
"""

import inspect
from sklearn.linalg import svdvals

def help():
    try:
        sig = inspect.signature(svdvals)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/svdvals",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "svdvals from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = svdvals(**params)
        else:
            result = svdvals()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
