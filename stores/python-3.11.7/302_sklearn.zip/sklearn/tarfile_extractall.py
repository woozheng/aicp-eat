"""
tarfile_extractall from sklearn
Route: POST /api/sklearn/tarfile_extractall
"""

import inspect
from sklearn.fixes import tarfile_extractall

def help():
    try:
        sig = inspect.signature(tarfile_extractall)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/tarfile_extractall",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "tarfile_extractall from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = tarfile_extractall(**params)
        else:
            result = tarfile_extractall()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
