"""
type_of_target from sklearn
Route: POST /api/sklearn/type_of_target
"""

import inspect
from sklearn.multiclass import type_of_target

def help():
    try:
        sig = inspect.signature(type_of_target)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/type_of_target",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "type_of_target from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = type_of_target(**params)
        else:
            result = type_of_target()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
