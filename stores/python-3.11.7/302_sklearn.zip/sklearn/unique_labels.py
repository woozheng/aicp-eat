"""
unique_labels from sklearn
Route: POST /api/sklearn/unique_labels
"""

import inspect
from sklearn.multiclass import unique_labels

def help():
    try:
        sig = inspect.signature(unique_labels)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/unique_labels",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "unique_labels from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = unique_labels(**params)
        else:
            result = unique_labels()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
