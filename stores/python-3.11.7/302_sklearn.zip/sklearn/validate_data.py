"""
validate_data from sklearn
Route: POST /api/sklearn/validate_data
"""

import inspect
from sklearn.validation import validate_data

def help():
    try:
        sig = inspect.signature(validate_data)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/validate_data",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "validate_data from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = validate_data(**params)
        else:
            result = validate_data()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
