"""
weighted_mode from sklearn
Route: POST /api/sklearn/weighted_mode
"""

import inspect
from sklearn.extmath import weighted_mode

def help():
    try:
        sig = inspect.signature(weighted_mode)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/weighted_mode",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "weighted_mode from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = weighted_mode(**params)
        else:
            result = weighted_mode()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
