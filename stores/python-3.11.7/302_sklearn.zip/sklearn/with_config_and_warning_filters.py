"""
with_config_and_warning_filters from sklearn
Route: POST /api/sklearn/with_config_and_warning_filters
"""

import inspect
from sklearn.parallel import with_config_and_warning_filters

def help():
    try:
        sig = inspect.signature(with_config_and_warning_filters)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/sklearn/with_config_and_warning_filters",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "with_config_and_warning_filters from sklearn"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = with_config_and_warning_filters(**params)
        else:
            result = with_config_and_warning_filters()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "sklearn"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
