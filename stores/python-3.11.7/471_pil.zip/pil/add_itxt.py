"""
add_itxt from PIL
Route: POST /api/pil/add_itxt
"""

import inspect
from PIL.PngImagePlugin import add_itxt

def help():
    try:
        sig = inspect.signature(add_itxt)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/add_itxt",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "add_itxt from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = add_itxt(**params)
        else:
            result = add_itxt()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
