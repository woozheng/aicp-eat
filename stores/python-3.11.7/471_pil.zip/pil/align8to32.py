"""
align8to32 from PIL
Route: POST /api/pil/align8to32
"""

import inspect
from PIL.ImageQt import align8to32

def help():
    try:
        sig = inspect.signature(align8to32)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/align8to32",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "align8to32 from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = align8to32(**params)
        else:
            result = align8to32()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
