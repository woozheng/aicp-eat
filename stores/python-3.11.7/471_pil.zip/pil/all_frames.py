"""
all_frames from PIL
Route: POST /api/pil/all_frames
"""

import inspect
from PIL.ImageSequence import all_frames

def help():
    try:
        sig = inspect.signature(all_frames)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/all_frames",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "all_frames from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = all_frames(**params)
        else:
            result = all_frames()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
