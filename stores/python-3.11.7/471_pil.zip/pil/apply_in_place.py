"""
apply_in_place from PIL
Route: POST /api/pil/apply_in_place
"""

import inspect
from PIL.ImageCms import apply_in_place

def help():
    try:
        sig = inspect.signature(apply_in_place)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/apply_in_place",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "apply_in_place from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = apply_in_place(**params)
        else:
            result = apply_in_place()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
