"""
applyTransform from PIL
Route: POST /api/pil/applytransform
"""

import inspect
from PIL.ImageCms import applyTransform

def help():
    try:
        sig = inspect.signature(applyTransform)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/applytransform",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "applyTransform from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = applyTransform(**params)
        else:
            result = applyTransform()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
