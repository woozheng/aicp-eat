"""
basic_handler from PIL
Route: POST /api/pil/basic_handler
"""

import inspect
from PIL.TiffImagePlugin import basic_handler

def help():
    try:
        sig = inspect.signature(basic_handler)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/basic_handler",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "basic_handler from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = basic_handler(**params)
        else:
            result = basic_handler()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
