"""
build_lut from PIL
Route: POST /api/pil/build_lut
"""

import inspect
from PIL.ImageMorph import build_lut

def help():
    try:
        sig = inspect.signature(build_lut)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/build_lut",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "build_lut from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = build_lut(**params)
        else:
            result = build_lut()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
