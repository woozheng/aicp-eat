"""
check_format_condition from PIL
Route: POST /api/pil/check_format_condition
"""

import inspect
from PIL.PdfParser import check_format_condition

def help():
    try:
        sig = inspect.signature(check_format_condition)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/check_format_condition",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "check_format_condition from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = check_format_condition(**params)
        else:
            result = check_format_condition()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
