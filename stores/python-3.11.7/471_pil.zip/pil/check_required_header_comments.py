"""
check_required_header_comments from PIL
Route: POST /api/pil/check_required_header_comments
"""

import inspect
from PIL.EpsImagePlugin import check_required_header_comments

def help():
    try:
        sig = inspect.signature(check_required_header_comments)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/check_required_header_comments",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "check_required_header_comments from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = check_required_header_comments(**params)
        else:
            result = check_required_header_comments()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
