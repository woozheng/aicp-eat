"""
check_text_memory from PIL
Route: POST /api/pil/check_text_memory
"""

import inspect
from PIL.PngImagePlugin import check_text_memory

def help():
    try:
        sig = inspect.signature(check_text_memory)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/check_text_memory",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "check_text_memory from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = check_text_memory(**params)
        else:
            result = check_text_memory()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
