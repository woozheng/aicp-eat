"""
chunk_cHRM from PIL
Route: POST /api/pil/chunk_chrm
"""

import inspect
from PIL.PngImagePlugin import chunk_cHRM

def help():
    try:
        sig = inspect.signature(chunk_cHRM)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/chunk_chrm",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "chunk_cHRM from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = chunk_cHRM(**params)
        else:
            result = chunk_cHRM()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
