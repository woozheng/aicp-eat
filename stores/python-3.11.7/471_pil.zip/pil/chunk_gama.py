"""
chunk_gAMA from PIL
Route: POST /api/pil/chunk_gama
"""

import inspect
from PIL.PngImagePlugin import chunk_gAMA

def help():
    try:
        sig = inspect.signature(chunk_gAMA)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/chunk_gama",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "chunk_gAMA from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = chunk_gAMA(**params)
        else:
            result = chunk_gAMA()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
