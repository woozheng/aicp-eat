"""
chunk_IHDR from PIL
Route: POST /api/pil/chunk_ihdr
"""

import inspect
from PIL.PngImagePlugin import chunk_IHDR

def help():
    try:
        sig = inspect.signature(chunk_IHDR)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/chunk_ihdr",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "chunk_IHDR from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = chunk_IHDR(**params)
        else:
            result = chunk_IHDR()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
