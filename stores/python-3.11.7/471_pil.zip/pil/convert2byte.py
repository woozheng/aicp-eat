"""
convert2byte from PIL
Route: POST /api/pil/convert2byte
"""

import inspect
from PIL.SpiderImagePlugin import convert2byte

def help():
    try:
        sig = inspect.signature(convert2byte)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/convert2byte",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "convert2byte from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = convert2byte(**params)
        else:
            result = convert2byte()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
