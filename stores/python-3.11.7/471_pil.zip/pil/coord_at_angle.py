"""
coord_at_angle from PIL
Route: POST /api/pil/coord_at_angle
"""

import inspect
from PIL.ImageDraw import coord_at_angle

def help():
    try:
        sig = inspect.signature(coord_at_angle)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/coord_at_angle",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "coord_at_angle from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = coord_at_angle(**params)
        else:
            result = coord_at_angle()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
