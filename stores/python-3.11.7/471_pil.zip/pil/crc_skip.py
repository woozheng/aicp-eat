"""
crc_skip from PIL
Route: POST /api/pil/crc_skip
"""

import inspect
from PIL.PngImagePlugin import crc_skip

def help():
    try:
        sig = inspect.signature(crc_skip)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/crc_skip",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "crc_skip from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = crc_skip(**params)
        else:
            result = crc_skip()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
