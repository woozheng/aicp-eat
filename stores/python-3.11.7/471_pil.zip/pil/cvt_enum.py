"""
cvt_enum from PIL
Route: POST /api/pil/cvt_enum
"""

import inspect
from PIL.TiffTags import cvt_enum

def help():
    try:
        sig = inspect.signature(cvt_enum)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/cvt_enum",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "cvt_enum from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = cvt_enum(**params)
        else:
            result = cvt_enum()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
