"""
draw_corners from PIL
Route: POST /api/pil/draw_corners
"""

import inspect
from PIL.ImageDraw import draw_corners

def help():
    try:
        sig = inspect.signature(draw_corners)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/draw_corners",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "draw_corners from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = draw_corners(**params)
        else:
            result = draw_corners()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
