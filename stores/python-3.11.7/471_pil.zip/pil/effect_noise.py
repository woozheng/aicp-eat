"""
effect_noise from PIL
Route: POST /api/pil/effect_noise
"""

import inspect
from PIL.Image import effect_noise

def help():
    try:
        sig = inspect.signature(effect_noise)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/effect_noise",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "effect_noise from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = effect_noise(**params)
        else:
            result = effect_noise()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
