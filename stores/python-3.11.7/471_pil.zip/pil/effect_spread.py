"""
effect_spread from PIL
Route: POST /api/pil/effect_spread
"""

import inspect
from PIL.Image import effect_spread

def help():
    try:
        sig = inspect.signature(effect_spread)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/effect_spread",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "effect_spread from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = effect_spread(**params)
        else:
            result = effect_spread()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
