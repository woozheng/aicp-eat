"""
embed_color from PIL
Route: POST /api/pil/embed_color
"""

import inspect
from PIL.ImageText import embed_color

def help():
    try:
        sig = inspect.signature(embed_color)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/embed_color",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "embed_color from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = embed_color(**params)
        else:
            result = embed_color()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
