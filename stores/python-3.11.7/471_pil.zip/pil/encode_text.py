"""
encode_text from PIL
Route: POST /api/pil/encode_text
"""

import inspect
from PIL.PdfParser import encode_text

def help():
    try:
        sig = inspect.signature(encode_text)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/encode_text",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "encode_text from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = encode_text(**params)
        else:
            result = encode_text()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
