"""
encode_to_pyfd from PIL
Route: POST /api/pil/encode_to_pyfd
"""

import inspect
from PIL.ImageFile import encode_to_pyfd

def help():
    try:
        sig = inspect.signature(encode_to_pyfd)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/encode_to_pyfd",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "encode_to_pyfd from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = encode_to_pyfd(**params)
        else:
            result = encode_to_pyfd()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
