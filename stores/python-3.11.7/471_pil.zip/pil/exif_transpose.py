"""
exif_transpose from PIL
Route: POST /api/pil/exif_transpose
"""

import inspect
from PIL.ImageOps import exif_transpose

def help():
    try:
        sig = inspect.signature(exif_transpose)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/exif_transpose",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "exif_transpose from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = exif_transpose(**params)
        else:
            result = exif_transpose()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
