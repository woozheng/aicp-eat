"""
font_variant from PIL
Route: POST /api/pil/font_variant
"""

import inspect
from PIL.ImageFont import font_variant

def help():
    try:
        sig = inspect.signature(font_variant)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/font_variant",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "font_variant from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = font_variant(**params)
        else:
            result = font_variant()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
