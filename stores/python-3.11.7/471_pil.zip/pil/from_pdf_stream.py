"""
from_pdf_stream from PIL
Route: POST /api/pil/from_pdf_stream
"""

import inspect
from PIL.PdfParser import from_pdf_stream

def help():
    try:
        sig = inspect.signature(from_pdf_stream)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/from_pdf_stream",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "from_pdf_stream from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = from_pdf_stream(**params)
        else:
            result = from_pdf_stream()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
