"""
frombytes from PIL
Route: POST /api/pil/frombytes
"""

import inspect
from PIL.GimpPaletteFile import frombytes

def help():
    try:
        sig = inspect.signature(frombytes)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/frombytes",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "frombytes from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = frombytes(**params)
        else:
            result = frombytes()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
