"""
get_child_images from PIL
Route: POST /api/pil/get_child_images
"""

import inspect
from PIL.Image import get_child_images

def help():
    try:
        sig = inspect.signature(get_child_images)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/get_child_images",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "get_child_images from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = get_child_images(**params)
        else:
            result = get_child_images()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
