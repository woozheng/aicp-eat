"""
get_display_profile from PIL
Route: POST /api/pil/get_display_profile
"""

import inspect
from PIL.ImageCms import get_display_profile

def help():
    try:
        sig = inspect.signature(get_display_profile)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/get_display_profile",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "get_display_profile from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = get_display_profile(**params)
        else:
            result = get_display_profile()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
