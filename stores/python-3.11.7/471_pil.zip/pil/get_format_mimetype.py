"""
get_format_mimetype from PIL
Route: POST /api/pil/get_format_mimetype
"""

import inspect
from PIL.ImageFile import get_format_mimetype

def help():
    try:
        sig = inspect.signature(get_format_mimetype)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/get_format_mimetype",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "get_format_mimetype from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = get_format_mimetype(**params)
        else:
            result = get_format_mimetype()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
