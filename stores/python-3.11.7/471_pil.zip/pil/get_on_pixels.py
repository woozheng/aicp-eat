"""
get_on_pixels from PIL
Route: POST /api/pil/get_on_pixels
"""

import inspect
from PIL.ImageMorph import get_on_pixels

def help():
    try:
        sig = inspect.signature(get_on_pixels)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/get_on_pixels",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "get_on_pixels from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = get_on_pixels(**params)
        else:
            result = get_on_pixels()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
