"""
get_supported from PIL
Route: POST /api/pil/get_supported
"""

import inspect
from PIL.features import get_supported

def help():
    try:
        sig = inspect.signature(get_supported)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/get_supported",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "get_supported from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = get_supported(**params)
        else:
            result = get_supported()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
