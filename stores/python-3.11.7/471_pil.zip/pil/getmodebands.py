"""
getmodebands from PIL
Route: POST /api/pil/getmodebands
"""

import inspect
from PIL.Image import getmodebands

def help():
    try:
        sig = inspect.signature(getmodebands)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/getmodebands",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "getmodebands from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = getmodebands(**params)
        else:
            result = getmodebands()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
