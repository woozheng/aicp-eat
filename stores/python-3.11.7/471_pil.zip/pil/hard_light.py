"""
hard_light from PIL
Route: POST /api/pil/hard_light
"""

import inspect
from PIL.ImageChops import hard_light

def help():
    try:
        sig = inspect.signature(hard_light)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/hard_light",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "hard_light from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = hard_light(**params)
        else:
            result = hard_light()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
