"""
has_ghostscript from PIL
Route: POST /api/pil/has_ghostscript
"""

import inspect
from PIL.EpsImagePlugin import has_ghostscript

def help():
    try:
        sig = inspect.signature(has_ghostscript)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/has_ghostscript",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "has_ghostscript from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = has_ghostscript(**params)
        else:
            result = has_ghostscript()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
