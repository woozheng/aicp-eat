"""
has_next_box from PIL
Route: POST /api/pil/has_next_box
"""

import inspect
from PIL.Jpeg2KImagePlugin import has_next_box

def help():
    try:
        sig = inspect.signature(has_next_box)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/has_next_box",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "has_next_box from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = has_next_box(**params)
        else:
            result = has_next_box()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
