"""
has_transparency_data from PIL
Route: POST /api/pil/has_transparency_data
"""

import inspect
from PIL.Image import has_transparency_data

def help():
    try:
        sig = inspect.signature(has_transparency_data)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/has_transparency_data",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "has_transparency_data from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = has_transparency_data(**params)
        else:
            result = has_transparency_data()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
