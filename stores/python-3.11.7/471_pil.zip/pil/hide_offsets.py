"""
hide_offsets from PIL
Route: POST /api/pil/hide_offsets
"""

import inspect
from PIL.Image import hide_offsets

def help():
    try:
        sig = inspect.signature(hide_offsets)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/hide_offsets",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "hide_offsets from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = hide_offsets(**params)
        else:
            result = hide_offsets()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
