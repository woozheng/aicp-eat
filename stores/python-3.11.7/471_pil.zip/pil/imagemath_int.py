"""
imagemath_int from PIL
Route: POST /api/pil/imagemath_int
"""

import inspect
from PIL.ImageMath import imagemath_int

def help():
    try:
        sig = inspect.signature(imagemath_int)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/imagemath_int",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "imagemath_int from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = imagemath_int(**params)
        else:
            result = imagemath_int()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
