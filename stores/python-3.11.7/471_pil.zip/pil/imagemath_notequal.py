"""
imagemath_notequal from PIL
Route: POST /api/pil/imagemath_notequal
"""

import inspect
from PIL.ImageMath import imagemath_notequal

def help():
    try:
        sig = inspect.signature(imagemath_notequal)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/imagemath_notequal",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "imagemath_notequal from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = imagemath_notequal(**params)
        else:
            result = imagemath_notequal()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
