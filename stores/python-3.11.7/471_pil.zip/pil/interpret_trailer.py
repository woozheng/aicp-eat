"""
interpret_trailer from PIL
Route: POST /api/pil/interpret_trailer
"""

import inspect
from PIL.PdfParser import interpret_trailer

def help():
    try:
        sig = inspect.signature(interpret_trailer)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/interpret_trailer",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "interpret_trailer from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = interpret_trailer(**params)
        else:
            result = interpret_trailer()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
