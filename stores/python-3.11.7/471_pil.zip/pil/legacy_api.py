"""
legacy_api from PIL
Route: POST /api/pil/legacy_api
"""

import inspect
from PIL.TiffImagePlugin import legacy_api

def help():
    try:
        sig = inspect.signature(legacy_api)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/legacy_api",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "legacy_api from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = legacy_api(**params)
        else:
            result = legacy_api()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
