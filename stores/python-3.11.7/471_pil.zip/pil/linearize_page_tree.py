"""
linearize_page_tree from PIL
Route: POST /api/pil/linearize_page_tree
"""

import inspect
from PIL.PdfParser import linearize_page_tree

def help():
    try:
        sig = inspect.signature(linearize_page_tree)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/linearize_page_tree",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "linearize_page_tree from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = linearize_page_tree(**params)
        else:
            result = linearize_page_tree()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
