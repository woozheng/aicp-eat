"""
load_djpeg from PIL
Route: POST /api/pil/load_djpeg
"""

import inspect
from PIL.JpegImagePlugin import load_djpeg

def help():
    try:
        sig = inspect.signature(load_djpeg)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/load_djpeg",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "load_djpeg from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = load_djpeg(**params)
        else:
            result = load_djpeg()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
