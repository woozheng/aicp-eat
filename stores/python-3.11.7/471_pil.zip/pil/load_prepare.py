"""
load_prepare from PIL
Route: POST /api/pil/load_prepare
"""

import inspect
from PIL.GifImagePlugin import load_prepare

def help():
    try:
        sig = inspect.signature(load_prepare)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/load_prepare",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "load_prepare from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = load_prepare(**params)
        else:
            result = load_prepare()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
