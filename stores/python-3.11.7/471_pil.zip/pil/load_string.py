"""
load_string from PIL
Route: POST /api/pil/load_string
"""

import inspect
from PIL.TiffImagePlugin import load_string

def help():
    try:
        sig = inspect.signature(load_string)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/load_string",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "load_string from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = load_string(**params)
        else:
            result = load_string()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
