"""
load_undefined from PIL
Route: POST /api/pil/load_undefined
"""

import inspect
from PIL.TiffImagePlugin import load_undefined

def help():
    try:
        sig = inspect.signature(load_undefined)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/load_undefined",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "load_undefined from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = load_undefined(**params)
        else:
            result = load_undefined()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
