"""
logical_xor from PIL
Route: POST /api/pil/logical_xor
"""

import inspect
from PIL.ImageChops import logical_xor

def help():
    try:
        sig = inspect.signature(logical_xor)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/logical_xor",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "logical_xor from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = logical_xor(**params)
        else:
            result = logical_xor()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
