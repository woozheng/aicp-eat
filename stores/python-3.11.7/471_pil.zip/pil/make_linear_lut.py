"""
make_linear_lut from PIL
Route: POST /api/pil/make_linear_lut
"""

import inspect
from PIL.ImagePalette import make_linear_lut

def help():
    try:
        sig = inspect.signature(make_linear_lut)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/make_linear_lut",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "make_linear_lut from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = make_linear_lut(**params)
        else:
            result = make_linear_lut()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
