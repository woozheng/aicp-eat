"""
multiline_text from PIL
Route: POST /api/pil/multiline_text
"""

import inspect
from PIL.ImageDraw import multiline_text

def help():
    try:
        sig = inspect.signature(multiline_text)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/multiline_text",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "multiline_text from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = multiline_text(**params)
        else:
            result = multiline_text()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
