"""
name_as_str from PIL
Route: POST /api/pil/name_as_str
"""

import inspect
from PIL.PdfParser import name_as_str

def help():
    try:
        sig = inspect.signature(name_as_str)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/name_as_str",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "name_as_str from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = name_as_str(**params)
        else:
            result = name_as_str()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
