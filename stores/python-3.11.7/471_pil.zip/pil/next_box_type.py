"""
next_box_type from PIL
Route: POST /api/pil/next_box_type
"""

import inspect
from PIL.Jpeg2KImagePlugin import next_box_type

def help():
    try:
        sig = inspect.signature(next_box_type)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/next_box_type",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "next_box_type from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = next_box_type(**params)
        else:
            result = next_box_type()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
