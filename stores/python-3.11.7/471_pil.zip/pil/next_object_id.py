"""
next_object_id from PIL
Route: POST /api/pil/next_object_id
"""

import inspect
from PIL.PdfParser import next_object_id

def help():
    try:
        sig = inspect.signature(next_object_id)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/next_object_id",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "next_object_id from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = next_object_id(**params)
        else:
            result = next_object_id()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
