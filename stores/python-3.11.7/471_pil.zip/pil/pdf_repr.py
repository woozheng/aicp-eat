"""
pdf_repr from PIL
Route: POST /api/pil/pdf_repr
"""

import inspect
from PIL.PdfParser import pdf_repr

def help():
    try:
        sig = inspect.signature(pdf_repr)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/pdf_repr",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "pdf_repr from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = pdf_repr(**params)
        else:
            result = pdf_repr()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
