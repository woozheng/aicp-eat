"""
pushes_fd from PIL
Route: POST /api/pil/pushes_fd
"""

import inspect
from PIL.ImageFile import pushes_fd

def help():
    try:
        sig = inspect.signature(pushes_fd)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/pushes_fd",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "pushes_fd from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = pushes_fd(**params)
        else:
            result = pushes_fd()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
