"""
putpixel from PIL
Route: POST /api/pil/putpixel
"""

import inspect
from PIL.Image import putpixel

def help():
    try:
        sig = inspect.signature(putpixel)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/putpixel",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "putpixel from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = putpixel(**params)
        else:
            result = putpixel()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
