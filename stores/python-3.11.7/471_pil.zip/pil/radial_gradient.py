"""
radial_gradient from PIL
Route: POST /api/pil/radial_gradient
"""

import inspect
from PIL.Image import radial_gradient

def help():
    try:
        sig = inspect.signature(radial_gradient)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/radial_gradient",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "radial_gradient from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = radial_gradient(**params)
        else:
            result = radial_gradient()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
