"""
register_decoder from PIL
Route: POST /api/pil/register_decoder
"""

import inspect
from PIL.Image import register_decoder

def help():
    try:
        sig = inspect.signature(register_decoder)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/register_decoder",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "register_decoder from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = register_decoder(**params)
        else:
            result = register_decoder()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
