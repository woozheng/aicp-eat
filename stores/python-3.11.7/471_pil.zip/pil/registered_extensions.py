"""
registered_extensions from PIL
Route: POST /api/pil/registered_extensions
"""

import inspect
from PIL.Image import registered_extensions

def help():
    try:
        sig = inspect.signature(registered_extensions)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/registered_extensions",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "registered_extensions from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = registered_extensions(**params)
        else:
            result = registered_extensions()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
