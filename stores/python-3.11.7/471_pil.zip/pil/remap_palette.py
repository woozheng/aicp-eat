"""
remap_palette from PIL
Route: POST /api/pil/remap_palette
"""

import inspect
from PIL.Image import remap_palette

def help():
    try:
        sig = inspect.signature(remap_palette)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/remap_palette",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "remap_palette from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = remap_palette(**params)
        else:
            result = remap_palette()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
