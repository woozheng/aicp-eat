"""
rewriteLastShortToLong from PIL
Route: POST /api/pil/rewritelastshorttolong
"""

import inspect
from PIL.TiffImagePlugin import rewriteLastShortToLong

def help():
    try:
        sig = inspect.signature(rewriteLastShortToLong)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/rewritelastshorttolong",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "rewriteLastShortToLong from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = rewriteLastShortToLong(**params)
        else:
            result = rewriteLastShortToLong()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
