"""
rounded_rectangle from PIL
Route: POST /api/pil/rounded_rectangle
"""

import inspect
from PIL.ImageDraw import rounded_rectangle

def help():
    try:
        sig = inspect.signature(rounded_rectangle)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/rounded_rectangle",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "rounded_rectangle from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = rounded_rectangle(**params)
        else:
            result = rounded_rectangle()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
