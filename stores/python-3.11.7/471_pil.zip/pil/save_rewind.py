"""
save_rewind from PIL
Route: POST /api/pil/save_rewind
"""

import inspect
from PIL.PngImagePlugin import save_rewind

def help():
    try:
        sig = inspect.signature(save_rewind)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/save_rewind",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "save_rewind from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = save_rewind(**params)
        else:
            result = save_rewind()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
