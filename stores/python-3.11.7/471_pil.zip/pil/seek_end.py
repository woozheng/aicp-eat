"""
seek_end from PIL
Route: POST /api/pil/seek_end
"""

import inspect
from PIL.PdfParser import seek_end

def help():
    try:
        sig = inspect.signature(seek_end)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/seek_end",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "seek_end from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = seek_end(**params)
        else:
            result = seek_end()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
