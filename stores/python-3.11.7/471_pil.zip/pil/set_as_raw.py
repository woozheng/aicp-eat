"""
set_as_raw from PIL
Route: POST /api/pil/set_as_raw
"""

import inspect
from PIL.ImageFile import set_as_raw

def help():
    try:
        sig = inspect.signature(set_as_raw)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/set_as_raw",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "set_as_raw from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = set_as_raw(**params)
        else:
            result = set_as_raw()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
