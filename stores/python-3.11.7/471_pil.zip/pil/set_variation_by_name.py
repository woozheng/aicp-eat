"""
set_variation_by_name from PIL
Route: POST /api/pil/set_variation_by_name
"""

import inspect
from PIL.ImageFont import set_variation_by_name

def help():
    try:
        sig = inspect.signature(set_variation_by_name)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/set_variation_by_name",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "set_variation_by_name from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = set_variation_by_name(**params)
        else:
            result = set_variation_by_name()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
