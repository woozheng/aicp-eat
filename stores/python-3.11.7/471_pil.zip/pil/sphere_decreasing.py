"""
sphere_decreasing from PIL
Route: POST /api/pil/sphere_decreasing
"""

import inspect
from PIL.GimpGradientFile import sphere_decreasing

def help():
    try:
        sig = inspect.signature(sphere_decreasing)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/sphere_decreasing",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "sphere_decreasing from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = sphere_decreasing(**params)
        else:
            result = sphere_decreasing()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
