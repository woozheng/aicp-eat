"""
sphere_increasing from PIL
Route: POST /api/pil/sphere_increasing
"""

import inspect
from PIL.GimpGradientFile import sphere_increasing

def help():
    try:
        sig = inspect.signature(sphere_increasing)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/sphere_increasing",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "sphere_increasing from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = sphere_increasing(**params)
        else:
            result = sphere_increasing()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
