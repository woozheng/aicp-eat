"""
start_writing from PIL
Route: POST /api/pil/start_writing
"""

import inspect
from PIL.PdfParser import start_writing

def help():
    try:
        sig = inspect.signature(start_writing)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/start_writing",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "start_writing from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = start_writing(**params)
        else:
            result = start_writing()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
