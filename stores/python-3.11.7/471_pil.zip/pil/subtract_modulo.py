"""
subtract_modulo from PIL
Route: POST /api/pil/subtract_modulo
"""

import inspect
from PIL.ImageChops import subtract_modulo

def help():
    try:
        sig = inspect.signature(subtract_modulo)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/subtract_modulo",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "subtract_modulo from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = subtract_modulo(**params)
        else:
            result = subtract_modulo()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
