"""
to_imagefont from PIL
Route: POST /api/pil/to_imagefont
"""

import inspect
from PIL.FontFile import to_imagefont

def help():
    try:
        sig = inspect.signature(to_imagefont)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/to_imagefont",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "to_imagefont from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = to_imagefont(**params)
        else:
            result = to_imagefont()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
