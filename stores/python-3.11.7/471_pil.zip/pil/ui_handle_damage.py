"""
ui_handle_damage from PIL
Route: POST /api/pil/ui_handle_damage
"""

import inspect
from PIL.ImageWin import ui_handle_damage

def help():
    try:
        sig = inspect.signature(ui_handle_damage)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/ui_handle_damage",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "ui_handle_damage from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = ui_handle_damage(**params)
        else:
            result = ui_handle_damage()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
