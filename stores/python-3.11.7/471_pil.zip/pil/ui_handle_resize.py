"""
ui_handle_resize from PIL
Route: POST /api/pil/ui_handle_resize
"""

import inspect
from PIL.ImageWin import ui_handle_resize

def help():
    try:
        sig = inspect.signature(ui_handle_resize)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/ui_handle_resize",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "ui_handle_resize from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = ui_handle_resize(**params)
        else:
            result = ui_handle_resize()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
