"""
unpack_565 from PIL
Route: POST /api/pil/unpack_565
"""

import inspect
from PIL.BlpImagePlugin import unpack_565

def help():
    try:
        sig = inspect.signature(unpack_565)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/unpack_565",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "unpack_565 from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = unpack_565(**params)
        else:
            result = unpack_565()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
