"""
validate_qtables from PIL
Route: POST /api/pil/validate_qtables
"""

import inspect
from PIL.JpegImagePlugin import validate_qtables

def help():
    try:
        sig = inspect.signature(validate_qtables)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/validate_qtables",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "validate_qtables from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = validate_qtables(**params)
        else:
            result = validate_qtables()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
