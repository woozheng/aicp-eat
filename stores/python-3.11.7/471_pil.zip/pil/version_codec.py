"""
version_codec from PIL
Route: POST /api/pil/version_codec
"""

import inspect
from PIL.features import version_codec

def help():
    try:
        sig = inspect.signature(version_codec)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pil/version_codec",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "version_codec from PIL"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = version_codec(**params)
        else:
            result = version_codec()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pil"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
