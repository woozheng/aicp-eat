"""
DataFrame from pandas
Route: POST /api/pandas/dataframe
"""

import inspect
from pandas import DataFrame

def help():
    try:
        sig = inspect.signature(DataFrame.__init__)
        params = {}
        for name, param in sig.parameters.items():
            if name == "self":
                continue
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/pandas/dataframe",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "DataFrame from pandas"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        content = payload.get("content", "")
        params = payload.get("params", {})
        
        try:
            if params:
                instance = DataFrame(**params)
            else:
                instance = DataFrame()
        except:
            try:
                instance = DataFrame()
            except:
                instance = DataFrame(content)
        
        try:
            result = instance.head()
        except (AttributeError, TypeError):
            result = instance
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif hasattr(result, "tolist"):
            result = result.tolist()
        elif hasattr(result, "content"):
            result = result.content
        elif hasattr(result, "page_content"):
            result = result.page_content
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        elif isinstance(result, dict):
            result = result.get("output", result.get("result", str(result)))
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "pandas"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
