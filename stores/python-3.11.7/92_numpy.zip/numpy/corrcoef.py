"""
corrcoef from numpy
Route: POST /api/numpy/corrcoef
"""

import inspect
import numpy

def help():
    try:
        func = getattr(numpy, "corrcoef")
        sig = inspect.signature(func)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/numpy/corrcoef",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "corrcoef from numpy"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        func = getattr(numpy, "corrcoef")
        
        if params:
            result = func(**params)
        else:
            result = func()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "numpy"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
