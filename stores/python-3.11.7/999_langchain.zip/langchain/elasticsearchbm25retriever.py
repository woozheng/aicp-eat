"""
ElasticSearchBM25Retriever from LangChain
Route: POST /api/langchain/elasticsearchbm25retriever
"""

import inspect
from langchain_community.retrievers.elastic_search_bm25 import ElasticSearchBM25Retriever

def help():
    try:
        sig = inspect.signature(ElasticSearchBM25Retriever.__init__)
        params = {}
        for name, param in sig.parameters.items():
            if name == "self":
                continue
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/langchain/elasticsearchbm25retriever",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "ElasticSearchBM25Retriever from LangChain"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        content = payload.get("content", "")
        params = payload.get("params", {})
        
        try:
            if params:
                instance = ElasticSearchBM25Retriever(**params)
            else:
                instance = ElasticSearchBM25Retriever(content)
        except:
            try:
                instance = ElasticSearchBM25Retriever()
            except:
                instance = ElasticSearchBM25Retriever(content)
        
        result = None
        if hasattr(instance, "get_relevant_documents"):
            result = instance.get_relevant_documents(content)
        elif hasattr(instance, "run"):
            result = instance.run(content)
        elif hasattr(instance, "invoke"):
            result = instance.invoke(content)
        elif hasattr(instance, "load"):
            result = instance.load()
        elif hasattr(instance, "predict"):
            result = instance.predict(content)
        elif hasattr(instance, "transform"):
            result = instance.transform(content)
        elif hasattr(instance, "fit_predict"):
            result = instance.fit_predict(content)
        elif hasattr(instance, "similarity_search"):
            result = instance.similarity_search(content)
        elif hasattr(instance, "load_data"):
            result = instance.load_data()
        else:
            result = str(instance)
        
        if hasattr(result, "content"):
            result = result.content
        elif hasattr(result, "page_content"):
            result = result.page_content
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        elif isinstance(result, dict):
            result = result.get("output", result.get("result", str(result)))
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "langchain"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
