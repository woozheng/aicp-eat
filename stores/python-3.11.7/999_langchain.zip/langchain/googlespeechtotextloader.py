"""
GoogleSpeechToTextLoader from LangChain
Route: POST /api/langchain/googlespeechtotextloader
"""

import inspect
from langchain_community.document_loaders.google_speech_to_text import GoogleSpeechToTextLoader

def help():
    try:
        sig = inspect.signature(GoogleSpeechToTextLoader.__init__)
        params = {}
        for name, param in sig.parameters.items():
            if name == "self":
                continue
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/langchain/googlespeechtotextloader",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "GoogleSpeechToTextLoader from LangChain"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        content = payload.get("content", "")
        params = payload.get("params", {})
        
        try:
            if params:
                instance = GoogleSpeechToTextLoader(**params)
            else:
                instance = GoogleSpeechToTextLoader(content)
        except:
            try:
                instance = GoogleSpeechToTextLoader()
            except:
                instance = GoogleSpeechToTextLoader(content)
        
        result = None
        if hasattr(instance, "load"):
            result = instance.load()
        elif hasattr(instance, "run"):
            result = instance.run()
        elif hasattr(instance, "invoke"):
            result = instance.invoke()
        elif hasattr(instance, "load"):
            result = instance.load()
        elif hasattr(instance, "predict"):
            result = instance.predict(content)
        elif hasattr(instance, "transform"):
            result = instance.transform(content)
        elif hasattr(instance, "fit_predict"):
            result = instance.fit_predict(content)
        elif hasattr(instance, "similarity_search"):
            result = instance.similarity_search(content)
        elif hasattr(instance, "load_data"):
            result = instance.load_data()
        else:
            result = str(instance)
        
        if hasattr(result, "content"):
            result = result.content
        elif hasattr(result, "page_content"):
            result = result.page_content
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        elif isinstance(result, dict):
            result = result.get("output", result.get("result", str(result)))
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "langchain"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
