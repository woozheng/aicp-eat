"""
options from requests
Route: POST /api/requests/options
"""

import inspect
from requests.api import options

def help():
    try:
        sig = inspect.signature(options)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/requests/options",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "options from requests"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = options(**params)
        else:
            result = options()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "requests"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
