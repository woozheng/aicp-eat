"""
put from requests
Route: POST /api/requests/put
"""

import inspect
from requests.api import put

def help():
    try:
        sig = inspect.signature(put)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/requests/put",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "put from requests"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = put(**params)
        else:
            result = put()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "requests"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
