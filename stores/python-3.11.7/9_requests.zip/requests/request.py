"""
request from requests
Route: POST /api/requests/request
"""

import inspect
from requests.api import request

def help():
    try:
        sig = inspect.signature(request)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/requests/request",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "request from requests"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = request(**params)
        else:
            result = request()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "requests"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
