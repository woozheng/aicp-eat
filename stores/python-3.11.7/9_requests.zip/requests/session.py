"""
session from requests
Route: POST /api/requests/session
"""

import inspect
from requests.sessions import session

def help():
    try:
        sig = inspect.signature(session)
        params = {}
        for name, param in sig.parameters.items():
            if param.default is inspect.Parameter.empty:
                params[name] = "<required>"
            else:
                params[name] = str(param.default)
    except:
        params = {"content": "input"}
    
    return {
        "route": "/api/requests/session",
        "input": {"params": params},
        "output": {"result": "output"},
        "description": "session from requests"
    }

async def execute(envelop, agent):
    try:
        payload = envelop.payload
        params = payload.get("params", {})
        
        if params:
            result = session(**params)
        else:
            result = session()
        
        if hasattr(result, "to_dict"):
            result = result.to_dict()
        elif isinstance(result, list):
            result = [str(r) for r in result[:10]]
        else:
            result = str(result)
        
        envelop.payload["result"] = result
        envelop.payload["source"] = "requests"
    except Exception as e:
        envelop.payload["error"] = str(e)
    return envelop
